export default [
    {
        label: `几何`,
        name: `geo`,
        list: [
            {
                symbol: `⊥`,
                latex: `\\perp`,
                title: `垂直`
            },
            {
                symbol: `∥`,
                latex: `\\parallel`,
                title: `平行`
            },
            {
                symbol: `∠`,
                latex: `\\angle{a}`,
                title: `角`
            },
            {
                symbol: `∡`,
                latex: `\\measuredangle`,
                title: `角`
            },
            {
                symbol: `Δ`,
                latex: `\\Delta`,
                title: `三角形`
            },
            {
                symbol: `≌`,
                latex: `\\Delta{a} \\cong \\Delta{b}`,
                title: `全等`
            }
        ]
    },
    {
        label: `代数`,
        name: `algebra`,
        list: [
            {
                symbol: `∝`,
                latex: `{a} \\propto {b}`,
                title: `正比`
            },
            {
                symbol: `∧`,
                latex: `{a} \\wedge {b}`,
                title: `逻辑与`
            },
            {
                symbol: `∨`,
                latex: `{a} \\vee {b}`,
                title: `逻辑或`
            },
            {
                symbol: `~`,
                latex: `{a} \\sim {b}`,
                title: `相似于`
            },
            {
                symbol: `≠`,
                latex: `{a} \\neq {b}`,
                title: `不等于`
            },
            {
                symbol: `≥`,
                latex: `{a} \\geq {b}`,
                title: `大于等于`
            },
            {
                symbol: `≤`,
                latex: `{a} \\leq {b}`,
                title: `小于等于`
            },
            {
                symbol: `＞`,
                latex: `{a} > {b}`,
                title: `大于`
            },
            {
                symbol: `＜`,
                latex: `{a} < {b}`,
                title: `小于`
            },
            {
                symbol: `≈`,
                latex: `{a} \\approx {b}`,
                title: `约等于`
            },
            {
                symbol: `∞`,
                latex: `\\infty`,
                title: `无穷`
            },
            {
                symbol: `±`,
                latex: `{a} \\pm {b}`,
                title: `正负`
            },
            {
                symbol: `∓`,
                latex: `{a} \\mp {b}`,
                title: `负正`
            },
            {
                symbol: `≡`,
                latex: `\\equiv`,
                title: `恒等于`
            },
            {
                symbol: `i`,
                latex: `i`,
                title: `虚数`
            }
        ]
    },
    {
        label: `运算符号`,
        name: `signs`,
        list: [
            {
                symbol: `+`,
                latex: `{a} + {b}`,
                title: `加`
            },
            {
                symbol: `-`,
                latex: `{a} - {b}`,
                title: `减`
            },
            {
                symbol: `*`,
                latex: `{a} \\times {b}`,
                title: `乘`
            },
            {
                symbol: `/`,
                latex: `{a} \\div {b}`,
                title: `除`
            },
            {
                symbol: `点乘`,
                latex: `\\cdot`,
                title: `点乘`
            },
            {
                symbol: `∪`,
                latex: `{a} \\cup {b}`,
                title: `合集`
            },
            {
                symbol: `∩`,
                latex: `{a}\\cap {b}`,
                title: `并集`
            },
            {
                symbol: `\\`,
                latex: `{a} \\backslash {b}`,
                title: `差集`
            },
            {
                symbol: `△`,
                latex: `{a} \\triangle {b}`,
                title: `差集`
            },
            {
                symbol: `√`,
                latex: `{a} \\sqrt {b}`,
                title: `平方根`
            },
            {
                symbol: `方根`,
                latex: `\\sqrt[n]{a}`,
                title: `方根`
            },
            {
                symbol: `:`,
                latex: `\\colon`,
                title: `比`
            },
            {
                symbol: `e`,
                latex: `e`,
                title: `自然对数底`
            },
            {
                symbol: `!`,
                latex: `!`,
                title: `阶乘`
            },
            {
                symbol: `|a|`,
                latex: `|{a}|`,
                title: `绝对值`
            },
            {
                symbol: `a'`,
                latex: `{a}'`,
                title: `求导`
            }
        ]
    },
    {
        label: `结合符号`,
        name: `pair`,
        list: [
            {
                symbol: `{`,
                latex: `\\{`,
                title: `左花括号`
            },
            {
                symbol: `}`,
                latex: `\\}`,
                title: `右花括号`
            },
            {
                symbol: `[`,
                latex: `[`,
                title: `左方括号`
            },
            {
                symbol: `]`,
                latex: `]`,
                title: `右方括号`
            },
            {
                symbol: `(`,
                latex: `(`,
                title: `左括号`
            },
            {
                symbol: `)`,
                latex: `)`,
                title: `右括号`
            },
            {
                symbol: `⌈`,
                latex: `\\lceil`,
                title: `左上界`
            },
            {
                symbol: `⌉`,
                latex: `\\rceil`,
                title: `右上界`
            },
            {
                symbol: `⌊`,
                latex: `\\lfloor`,
                title: `左下界`
            },
            {
                symbol: `⌋`,
                latex: `\\rfloor`,
                title: `右下界`
            }
        ]
    },
    {
        label: `公式符号`,
        name: `formula`,
        list: [
            {
                symbol: `log`,
                latex: `\\log_{a}{b}`
            },
            {
                symbol: `lg`,
                latex: `\\lg{a}`
            },
            {
                symbol: `ln`,
                latex: `\\ln{a}`
            },
            {
                symbol: `e`,
                latex: `e`,
                title: `自然对数`
            },
            {
                symbol: `sin`,
                latex: `\\sin{x}`,
                label: `正弦`
            },
            {
                symbol: `cos`,
                latex: `\\cos{x}`,
                label: `余弦`
            },
            {
                symbol: `tan`,
                latex: `\\tan{x}`,
                label: `正切`
            },
            {
                symbol: `sec`,
                latex: `\\sec{x}`,
                label: `正割`
            },
            {
                symbol: `csc`,
                latex: `\\csc{x}`,
                label: `余割`
            },
            {
                symbol: `cot`,
                latex: `\\cot{x}`,
                label: `余切`
            },
            {
                symbol: `sinh`,
                latex: `\\sinh{x}`,
                title: `双曲正弦`
            },
            {
                symbol: `cosh`,
                latex: `\\cosh{x}`,
                title: `双曲余弦`
            },
            {
                symbol: `tanh`,
                latex: `\\tanh{x}`,
                title: `双曲正切`
            },
            {
                symbol: `coth`,
                latex: `\\coth{x}`,
                title: `双曲余切`
            },
            {
                symbol: `arcsin`,
                latex: `\\arcsin{x}`,
                title: `反正弦`
            },
            {
                symbol: `arccos`,
                latex: `\\arccos{x}`,
                title: `反余弦`
            },
            {
                symbol: `arctan`,
                latex: `\\arctan{x}`,
                title: `反正切`
            },
            {
                symbol: `幂`,
                latex: `{a}^{x}`,
                title: `幂运算`
            },
            {
                symbol: `分数`,
                latex: `\\frac{a}{b}`,
                title: `分数`
            },
            {
                symbol: `排列`,
                latex: `A_{a}^{b}`,
                title: `排列数`
            },
            {
                symbol: `组合`,
                latex: `C_{a}^{b}`,
                title: `组合数`
            }
        ]
    },
    {
        label: `集合`,
        name: `set`,
        list: [
            {
                symbol: `⊆`,
                latex: `{a} \\subseteq {b}`,
                title: `子集`
            },
            {
                symbol: `⊂`,
                latex: `{a} \\subet {b}`,
                title: `子集`
            },
            {
                symbol: `⊊`,
                latex: `\\subsetneq`,
                title: `真子集`
            },
            {
                symbol: `⊇`,
                latex: `{a} \\supseteq {b}`,
                title: `超集`
            },
            {
                symbol: `⊊`,
                latex: `{a} \\supsetneq {b}`,
                title: `真超集`
            },
            {
                symbol: `∈`,
                latex: `{a} \\in {b}`,
                title: `属于`
            },
            {
                symbol: `∋`,
                latex: `{a} \\ni {b}`,
                title: `属于`
            },
            {
                symbol: `∉`,
                latex: `{a} \\notin {b}`,
                title: `不属于`
            },
            {
                symbol: `∉`,
                latex: `{a} \\not\\ni {b}`,
                title: `不属于`
            }
        ]
    },
    {
        label: `数集`,
        name: `numberSet`,
        list: [
            {
                symbol: `N`,
                latex: `\\mathbb{N}`,
                title: `自然数集`
            },
            {
                symbol: `Z`,
                latex: `\\mathbb{Z}`,
                title: `整数集`
            },
            {
                symbol: `Q`,
                latex: `\\mathbb{Q}`,
                title: `有理数集`
            },
            {
                symbol: `R`,
                latex: `\\mathbb{R}`,
                title: `实数集`
            },
            {
                symbol: `A`,
                latex: `\\mathbb{A}`,
                title: `无理集`
            },
            {
                symbol: `C`,
                latex: `\\mathbb{C}`,
                title: `复数集`
            }
        ]
    },
    {
        label: `其他符号`,
        name: `other`,
        list: [
            {
                symbol: `∵`,
                latex: `\\because`,
                title: `因为`
            },
            {
                symbol: `∴`,
                latex: `\\therefore`,
                title: `所以`
            },
            {
                symbol: `π`,
                latex: `\\pi`,
                title: `圆周率`
            },
            {
                symbol: `∑`,
                latex: `\\sum_{a}^{b}`,
                title: `总和`
            },
            {
                symbol: `↑`,
                latex: `\\uparrow`,
                title: `上箭头`
            },
            {
                symbol: `↓`,
                latex: `\\downarrow`,
                title: `下箭头`
            },
            {
                symbol: `←`,
                latex: `\\leftarrow`,
                title: `左箭头`
            },
            {
                symbol: `→`,
                latex: `\\rightarrow`,
                title: `右箭头`
            },
            {
                symbol: `⇒`,
                latex: `\\Rightarrow`,
                title: `双右箭头`
            },
            {
                symbol: `⇐`,
                latex: `\\Leftarrow`,
                title: `左箭头`
            },
            {
                symbol: `⇔`,
                latex: `\\Leftrightarrow`,
                title: `左右箭头`
            }
        ]
    }
];
