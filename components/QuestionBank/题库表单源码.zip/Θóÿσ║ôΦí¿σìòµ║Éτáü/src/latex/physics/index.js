export default [
    {
        symbol: `向量`,
        latex: `\\vec{x}`
    },

    {
        symbol: `积分`,
        latex: `\\oint_{a}^{b}`
    }
];
