export default [
    {
        symbol: `①`,
        latex: `①`
    },

    {
        symbol: `②`,
        latex: `②`
    },

    {
        symbol: `③`,
        latex: `③`
    },

    {
        symbol: `④`,
        latex: `④`
    },

    {
        symbol: `⑤`,
        latex: `⑤`
    },

    {
        symbol: `⑥`,
        latex: `⑥`
    },

    {
        symbol: `⑦`,
        latex: `⑦`
    },

    {
        symbol: `⑧`,
        latex: `⑧`
    },

    {
        symbol: `⑨`,
        latex: `⑨`
    },

    {
        symbol: `⑩`,
        latex: `⑩`
    },

    {
        symbol: `⑪`,
        latex: `⑪`
    },

    {
        symbol: `⑫`,
        latex: `⑫`
    },

    {
        symbol: `⑬`,
        latex: `⑬`
    },

    {
        symbol: `⑭`,
        latex: `⑭`
    },

    {
        symbol: `⑮`,
        latex: `⑮`
    },

    {
        symbol: `⑯`,
        latex: `⑯`
    },

    {
        symbol: `⑰`,
        latex: `⑰`
    },

    {
        symbol: `⑱`,
        latex: `⑱`
    },

    {
        symbol: `⑲`,
        latex: `⑲`
    },

    {
        symbol: `⑳`,
        latex: `⑳`
    }
];
