export default [
    {
        symbol: `α`,
        latex: `\\alpha`
    },

    {
        symbol: `β`,
        latex: `\\beta`
    },

    {
        symbol: `γ`,
        latex: `\\gamma`
    },

    {
        symbol: `δ`,
        latex: `\\delta`
    },

    {
        symbol: `ε`,
        latex: `\\epsilon`
    },

    {
        symbol: `ζ`,
        latex: `\\zeta`
    },

    {
        symbol: `η`,
        latex: `\\eta`
    },

    {
        symbol: `θ`,
        latex: `\\theta`
    },

    {
        symbol: `ι`,
        latex: `\\iota`
    },

    {
        symbol: `κ`,
        latex: `\\kappa`
    },

    {
        symbol: `λ`,
        latex: `\\lambda`
    },

    {
        symbol: `μ`,
        latex: `\\mu`
    },

    {
        symbol: `ν`,
        latex: `\\nu`
    },

    {
        symbol: `ξ`,
        latex: `\\xi`
    },

    {
        symbol: `ο`,
        latex: `\\omicron`
    },

    {
        symbol: `π`,
        latex: `\\pi`
    },

    {
        symbol: `ρ`,
        latex: `\\rho`
    },

    {
        symbol: `σ`,
        latex: `\\sigma`
    },

    {
        symbol: `τ`,
        latex: `\\tau`
    },

    {
        symbol: `υ`,
        latex: `\\upsilon`
    },

    {
        symbol: `φ`,
        latex: `\\phi`
    },

    {
        symbol: `χ`,
        latex: `\\chi`
    },

    {
        symbol: `ψ`,
        latex: `\\psi`
    },

    {
        symbol: `ω`,
        latex: `\\omega`
    },

    {
        symbol: `∂`,
        latex: `\\partial`
    }
];
