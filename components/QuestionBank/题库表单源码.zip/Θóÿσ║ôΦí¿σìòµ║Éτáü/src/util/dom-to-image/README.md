# 屏幕截图工具魔改 dom-to-image

```js
import { dom2image } from '@util/dom-to-image/src/dom-to-image';
```

生成 jpg 使用例

动态获取元素的宽高，然后生成图片

```js
const el = document.getElementById(`capture`);
const height = window
        .getComputedStyle(el)
        .getPropertyValue('height')
        .replace('px', ''),
    width = window
        .getComputedStyle(el)
        .getPropertyValue('width')
        .replace('px', '');
dom2image
    .toPng(el, {
        bgcolor: 'white',
        width,
        height,
        scale: 2,
        quality: 1
    })
    .then(dataUrl => {
        const link = document.createElement('a');
        link.download = 'question.png';
        link.href = dataUrl;
        link.click();
    });
```

## 其余用法与[dom-2-image](https://www.npmjs.com/package/dom-to-image)相同