<template>
  <quill-editor @input="handleEmit" :value="value" ref="quillEditor" :options="quillConfigs"></quill-editor>
</template>

<script>
import { quillEditor, Quill } from "vue-quill-editor";

import "quill/dist/quill.core.css";
import "quill/dist/quill.snow.css";
import katex from "katex";

const toolBar = [[`formula`]];
export default {
  props: {
    value: {
      type: String,
    },
  },

  components: {
    quillEditor,
  },

  data() {
    return {
      quill: null,
      quillConfigs: {
        placeholder: "",
        theme: "snow",
        modules: {
          toolbar: {
            container: toolBar,
            handlers: {},
          },
        },
      },
    };
  },

  methods: {
    handleEmit(e) {
      this.$emit("input", e);
    },

    editor() {
      return this.$refs.quillEditor.quill;
    },
  },

  mounted() {
    window.katex = katex;
  },
};
</script>

<style lang="scss" scoped>
::v-deep .ql-editor {
  min-height: 230px;
}

::v-deep .embed-innerApp {
  box-sizing: border-box;
  text-align: center;
  border: none;
  border-bottom: 1px solid #000000;
  border-radius: 0;
  box-shadow: none;
  -webkit-appearance: none;
  -webkit-tap-highlight-color: rgb(255, 255, 255);
  outline: none;
  padding: 2px;
  width: 100px;
  display: inline-block;
}
</style>
