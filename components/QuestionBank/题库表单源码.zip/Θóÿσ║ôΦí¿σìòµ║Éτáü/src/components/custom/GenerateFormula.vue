<template>
  <div id="formula" :class="visible ? 'show' : 'hidden'">
    <el-tabs value="math" :stretch="true">
      <el-tab-pane label="数学" name="math">
        <el-tabs :value="maths[0].name" :stretch="true">
          <el-tab-pane
            v-for="(item, index) in maths"
            :key="'maths' + index"
            :label="item.label"
            :name="item.name"
          >
            <el-button
              class="btn"
              v-for="(mathList, index) in item.list"
              :key="'math-sub' + index"
              @click.prevent.native="insertText(mathList.latex)"
              size="small"
              :title="mathList.title"
            >{{ mathList.symbol }}</el-button>
          </el-tab-pane>
        </el-tabs>
      </el-tab-pane>
      <el-tab-pane label="物理" name="physics">
        <el-button
          class="btn"
          v-for="(item, index) in physics"
          :key="'physics' + index"
          @click.prevent.native="insertText(item.latex)"
          size="small"
        >{{ item.symbol }}</el-button>
      </el-tab-pane>
      <el-tab-pane label="数字" name="number">
        <el-button
          class="btn"
          v-for="(item, index) in number"
          :key="'symbol' + index"
          @click.prevent.native="insertText(item.latex)"
          size="small"
        >{{ item.symbol }}</el-button>
      </el-tab-pane>
      <el-tab-pane label="符号" name="symbols">
        <el-button
          class="btn"
          v-for="(item, index) in symbols"
          :key="'symbol' + index"
          @click.prevent.native="insertText(item.latex)"
          size="small"
        >{{ item.symbol }}</el-button>
      </el-tab-pane>
      <!-- <el-tab-pane label="化学" name="chemistry" disabled></el-tab-pane>
      <el-tab-pane label="生物" name="biology" disabled></el-tab-pane>-->
    </el-tabs>

    <div class="wrap">
      <div class="formula-edit">
        <el-input
          ref="formula-input"
          class="input"
          id="formula-input"
          type="textarea"
          rows="4"
          placeholder="生成的公式"
          clearable
          v-model="formula"
        ></el-input>
      </div>
    </div>
  </div>
</template>

<script>
import maths from "@/latex/math/index";
import symbols from "@/latex/symbol/index";
import physics from "@/latex/physics/index";
import number from "@/latex/number/index";

import Clipboard from "clipboard";

export default {
  name: `GenerateFormula`,

  props: {
    visible: {
      type: Boolean,
      default: false,
    },
    value: {
      type: String,
    },
  },

  data() {
    return {
      formula: this.value,
      maths,
      symbols,
      physics,
      number,
    };
  },

  computed: {
    latexFormula() {
      return this.formula ? `$$${this.formula}$$` : "";
    },
  },

  methods: {
    insertText(text) {
      const el = this.$refs["formula-input"].$el.firstElementChild,
        currentInputText = el.value,
        // 获取选区开始位置
        startPos = el.selectionStart,
        // 获取选区结束位置
        endPos = el.selectionEnd;
      // 将文本插入光标位置
      this.formula = `${currentInputText.substring(
        0,
        startPos
      )}${text}${currentInputText.substring(endPos)}`;

      this.$nextTick(() => {
        el.selectionStart = el.selectionEnd = endPos + text.length;
        el.focus();
      });
    },

    /* **** 创建剪切板 **** */
    initClipboard() {
      const that = this;
      const clipboard = new Clipboard(".copy-btn");
      clipboard.on("success", function (e) {
        that.$message.success(`复制成功`);
        e.clearSelection();
      });
      clipboard.on("error", function (e) {
        that.$message.warning(`复制失败`);
      });
    },

    init() {
      this.initClipboard();
    },
  },

  mounted() {
    this.init();
  },

  watch: {
    formula() {
      this.$emit("input", this.formula);
      this.$nextTick(() => {
        window.MathJax.Hub.Queue(
          ["Typeset", MathJax.Hub],
          document.getElementById("formula")
        );
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.show {
  display: block;
}

.hidden {
  display: none !important;
}

.footer {
  margin-top: auto;
  align-self: flex-end;
}

#formula {
  display: flex;
  flex-direction: column;
  min-height: 60%;
  padding: 10px;
  border-radius: 15px;
  box-shadow: 0 0 3px #c2c2c2;
  overflow: auto;
  background-color: rgba($color: #ffffff, $alpha: 0.9);
}

.wrap {
  width: 80%;
  margin: 0 auto;
}

.btn {
  margin-bottom: 5px;
}

.formula-edit {
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  margin-top: 30px;

  .input {
  }

  .btn {
    margin-left: auto;
  }
}

.real-time-preview-wrap {
  margin-top: 50px;
  min-height: 200px;
  border-radius: 15px;
  box-shadow: 0px 0px 3px 1px lightgray;
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
}

::v-deep .mjx-chtml {
  outline: 0;
}

::v-deep .MJXc-display {
  overflow-x: auto;
  overflow-y: hidden;
}

::v-deep .el-drawer__wrapper {
  height: 100vh;
  width: 100%;
  z-index: 3000;
}
</style>
