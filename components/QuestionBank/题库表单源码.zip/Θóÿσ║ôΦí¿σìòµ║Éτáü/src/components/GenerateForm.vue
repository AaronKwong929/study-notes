<template>
  <div class="fm-style">
    <el-form
      ref="generateForm"
      v-if="reload"
      label-suffix=":"
      :size="data.config.size"
      :model="models"
      :label-position="data.config.labelPosition"
      :label-width="data.config.labelWidth + 'px'"
    >
      <template v-for="item in data.list">
        <template v-if="item.type == 'grid'">
          <el-row
            :key="item.key"
            type="flex"
            :gutter="item.options.gutter ? item.options.gutter : 0"
            :justify="item.options.justify"
            :align="item.options.align"
          >
            <el-col v-for="(col, colIndex) in item.columns" :key="colIndex" :span="col.span">
              <template v-for="citem in col.list">
                <el-form-item
                  v-if="citem.type=='blank'"
                  :label="citem.name"
                  :prop="citem.model"
                  :key="citem.key"
                >
                  <slot :name="citem.model" :model="models"></slot>
                </el-form-item>
                <genetate-form-item
                  v-else
                  :key="citem.key"
                  :models.sync="models"
                  :remote="remote"
                  :rules="rules"
                  :widget="citem"
                  @input-change="onInputChange"
                ></genetate-form-item>
              </template>
            </el-col>
          </el-row>
        </template>
        <!-- 题干布局区 -->
        <!--1. 默认布局 -->
        <template v-else-if="item.type == 'question_default'">
          <el-row
            :key="item.key"
            type="flex"
            :gutter="item.options.gutter ? item.options.gutter : 0"
            :justify="item.options.justify"
            :align="item.options.align"
            v-for="(row, rowIndex) in item.rows"
          >
            <el-col :key="rowIndex" :span="row.span ? row.span : 0">
              <template v-for="citem in row.list">
                <genetate-form-item
                  :key="citem.key"
                  :models.sync="models"
                  :remote="remote"
                  :widget="citem"
                  @input-change="onInputChange"
                ></genetate-form-item>
              </template>
            </el-col>
          </el-row>
        </template>
        <!-- 2.左右布局 -->
        <template v-else-if="item.type == 'question_lr'">
          <el-row
            :key="item.key"
            type="flex"
            :gutter="item.options.gutter ? item.options.gutter : 0"
            :justify="item.options.justify"
            :align="item.options.align"
          >
            <el-col
              v-for="(col, colIndex) in item.columns"
              :key="colIndex"
              :span="col.span ? col.span : 0"
            >
              <template v-for="citem in col.list">
                <genetate-form-item
                  :key="citem.key"
                  :models.sync="models"
                  :remote="remote"
                  :widget="citem"
                  @input-change="onInputChange"
                ></genetate-form-item>
              </template>
            </el-col>
          </el-row>
        </template>
        <!-- 3. 上下布局 -->
        <template v-else-if="item.type == 'question_tb'">
          <el-row
            :key="item.key"
            type="flex"
            :gutter="row.gutter ? row.gutter : 0"
            :justify="row.justify"
            :align="row.align"
            v-for="(row, rowIndex) in item.rows"
          >
            <!-- <el-col :key="rowIndex" :span="row.span ? row.span : 0"> -->
            <template v-for="citem in row.list">
              <genetate-form-item
                :key="citem.key"
                :models.sync="models"
                :remote="remote"
                :widget="citem"
                @input-change="onInputChange"
              ></genetate-form-item>
            </template>
            <!-- </el-col> -->
          </el-row>
        </template>

        <!-- 选项区 -->
        <!-- 1. 单行选项 -->
        <template v-else-if="item.type == 'option_row1'">
          <el-main :key="item.key">
            <el-row
              v-for="(row, rowIndex) in item.rows"
              :key="rowIndex"
              type="flex"
              :gutter="item.options.gutter ? item.options.gutter : 0"
              :justify="item.options.justify"
              :align="item.options.align"
              class="option_row"
            >
              <el-col v-for="(col, colIndex) in row.columns" :key="colIndex" :span="col.span">
                <label>{{col.label+item.options.splitter}}</label>
                <template v-for="citem in col.list">
                  <el-form-item
                    v-if="citem.type=='blank'"
                    :label="citem.name"
                    :prop="citem.model"
                    :key="citem.key"
                  >
                    <slot :name="citem.model" :model="models"></slot>
                  </el-form-item>
                  <genetate-form-item
                    v-else
                    :key="citem.key"
                    :models.sync="models"
                    :remote="remote"
                    :widget="citem"
                    @input-change="onInputChange"
                  ></genetate-form-item>
                </template>
              </el-col>
            </el-row>
          </el-main>
        </template>
        <!-- 2.单列选项 -->
        <template v-else-if="item.type == 'option_col1'">
          <el-main
            :key="item.key"
            type="flex"
            :gutter="item.options.gutter ? item.options.gutter : 0"
            :justify="item.options.justify"
            :align="item.options.align"
          >
            <el-row v-for="(row, rowIndex) in item.rows" :key="rowIndex" class="option_row">
              <el-col v-for="(col, colIndex) in row.columns" :key="colIndex" :span="col.span">
                <label>{{col.label+item.options.splitter}}</label>
                <template v-for="citem in col.list">
                  <el-form-item
                    v-if="citem.type=='blank'"
                    :label="citem.name"
                    :prop="citem.model"
                    :key="citem.key"
                  >
                    <slot :name="citem.model" :model="models"></slot>
                  </el-form-item>
                  <genetate-form-item
                    v-else
                    :key="citem.key"
                    :models.sync="models"
                    :remote="remote"
                    :widget="citem"
                    @input-change="onInputChange"
                  ></genetate-form-item>
                </template>
              </el-col>
            </el-row>
          </el-main>
        </template>
        <!-- 双列选项 -->
        <template v-else-if="item.type == 'option_col2'">
          <el-main :key="item.key">
            <el-row
              v-for="(row, rowIndex) in item.rows"
              :key="rowIndex"
              type="flex"
              :gutter="item.options.gutter ? item.options.gutter : 0"
              :justify="item.options.justify"
              :align="item.options.align"
              class="option_row"
            >
              <el-col v-for="(col, colIndex) in row.columns" :key="colIndex" :span="col.span">
                <label>{{col.label+item.options.splitter}}</label>
                <template v-for="citem in col.list">
                  <el-form-item
                    v-if="citem.type=='blank'"
                    :label="citem.name"
                    :prop="citem.model"
                    :key="citem.key"
                  >
                    <slot :name="citem.model" :model="models"></slot>
                  </el-form-item>
                  <genetate-form-item
                    v-else
                    :key="citem.key"
                    :models.sync="models"
                    :remote="remote"
                    :widget="citem"
                    @input-change="onInputChange"
                  ></genetate-form-item>
                </template>
              </el-col>
            </el-row>
          </el-main>
        </template>

        <template v-else-if="item.type == 'blank'">
          <el-form-item :label="item.name" :prop="item.model" :key="item.key">
            <slot :name="item.model" :model="models"></slot>
          </el-form-item>
        </template>

        <template v-else>
          <genetate-form-item
            :key="item.key"
            :models.sync="models"
            :widget="item"
            @input-change="onInputChange"
            :remote="remote"
          ></genetate-form-item>
        </template>
      </template>
    </el-form>
  </div>
</template>

<script>
import GenetateFormItem from "./GenerateFormItem";
import { loadJs } from "../util/index.js";

export default {
  name: "fm-generate-form",
  components: {
    GenetateFormItem,
  },
  props: ["data", "remote", "value", "insite"],
  data() {
    return {
      models: {},
      rules: {},
      reload: true,
    };
  },
  created() {
    this.generateModle(this.data.list);
  },
  mounted() {
    console.log("+++++++++____________++++++++++++++", this.data);
  },
  methods: {
    generateModle(genList) {
      for (let i = 0; i < genList.length; i++) {
        console.log(genList[i].type);
        // if (genList[i].type === "grid") {
        //   genList[i].columns.forEach((item) => {
        //     console.log(item.list);
        //     this.generateModle(item.list);
        //   });
        // } else
        if (genList[i].type.indexOf("question_default") !== -1) {
          console.log(genList[i]);
          genList[i].rows.forEach((item) => {
            this.generateModle(item.list);
          });
        } else if (genList[i].type.indexOf("question_lr") !== -1) {
          genList[i].columns.forEach((item) => {
            this.generateModle(item.list);
          });
        } else if (genList[i].type.indexOf("question_tb") !== -1) {
          genList[i].rows.forEach((item) => {
            this.generateModle(item.list);
          });
        }

        // 选项
        else if (genList[i].type.indexOf("option_") !== -1) {
          genList[i].rows.forEach((item) => {
            item.columns.forEach((colItem) => {
              this.generateModle(colItem.list);
            });
          });
        } else {
          if (
            this.value &&
            Object.keys(this.value).indexOf(genList[i].model) >= 0
          ) {
            this.models[genList[i].model] = this.value[genList[i].model];
          } else {
            if (genList[i].type === "blank") {
              this.$set(
                this.models,
                genList[i].model,
                genList[i].options.defaultType === "String"
                  ? ""
                  : genList[i].options.defaultType === "Object"
                  ? {}
                  : []
              );
            } else {
              this.models[genList[i].model] = genList[i].options.defaultValue;
            }
          }
        }
      }
      this.refresh();
    },
    getData() {
      return new Promise((resolve, reject) => {
        this.$refs.generateForm.validate((valid) => {
          if (valid) {
            resolve(this.models);
          } else {
            reject(new Error(this.$t("fm.message.validError")).message);
          }
        });
      });
    },
    reset() {
      this.$refs.generateForm.resetFields();
    },
    onInputChange(value, field) {
      this.$emit("on-change", field, value, this.models);
    },
    refresh() {
      this.reload = false;
      this.$nextTick(() => {
        this.reload = true;
      });
    },
  },
  watch: {
    data: {
      deep: true,
      handler(val) {
        console.log("-----------", val.list);

        this.$nextTick(() => {
          if (document.getElementById("formula")) {
            window.MathJax.Hub.Queue(
              ["Typeset", MathJax.Hub],
              document.getElementById("formula")
            );
          }
        });

        this.generateModle(val.list);
      },
    },
    value: {
      deep: true,
      handler(val) {
        console.log(JSON.stringify(val));
        this.models = { ...this.models, ...val };
      },
    },
  },
};
</script>

<style lang="scss">
// @import '../styles/cover.scss';
</style>
