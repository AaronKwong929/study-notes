<template>
  <div class="fm-uplaod-container" :id="uploadId">
    <div
      class="el-upload el-upload--picture-card"
      :class="{'is-disabled': disabled}"
      :style="{width: width+'px', height: height+'px'}"
      @click="handleAdd"
    >
      <div>
        <i
          class="el-icon-plus"
          @click="handleAdd"
          :style="{fontSize:miniWidth/4+'px',marginTop: (-miniWidth/8)+'px', marginLeft: (-miniWidth/8)+'px'}"
        ></i>
        <input
          accept="image/*"
          ref="uploadInput"
          @change="handleChange"
          type="file"
          :style="{width:0, height: 0}"
          name="file"
          class="el-upload__input upload-input"
        />
      </div>
    </div>
    <!-- <div
      class="el-upload el-upload--picture-card"
      :class="{'is-disabled': disabled}"
      v-else
      :style="{width: width+'px', height: height+'px'}"
      @click="handleAdd"
    >
      <img :src="url" @click="handleAdd" />
      <input
        accept="image/*"
        ref="uploadInput"
        @change="handleChange"
        type="file"
        :style="{width:0, height: 0}"
        name="file"
        class="el-upload__input upload-input"
      />
    </div>-->
  </div>
</template>

<script>
import Viewer from "viewerjs";
import Draggable from "vuedraggable";
import * as qiniu from "qiniu-js";
require("viewerjs/dist/viewer.css");
export default {
  components: {
    Draggable,
  },
  props: {
    value: {
      type: String,
      default: "",
    },
    width: {
      type: Number,
      default: 100,
    },
    height: {
      type: Number,
      default: 100,
    },
    token: {
      type: String,
      default: "",
    },
    domain: {
      type: String,
      default: "",
    },
    multiple: {
      type: Boolean,
      default: false,
    },
    length: {
      type: Number,
      default: 9,
    },
    isQiniu: {
      type: Boolean,
      default: false,
    },
    isDelete: {
      type: Boolean,
      default: false,
    },
    min: {
      type: Number,
      default: 0,
    },
    meitu: {
      type: Boolean,
      default: false,
    },
    isEdit: {
      type: Boolean,
      default: false,
    },
    action: {
      type: String,
      default: "",
    },
    type: {
      type: String,
      default: "src",
    },
  },
  data() {
    return {
      url: this.value,
      viewer: null,
      uploadId: "upload_" + new Date().getTime(),
      editIndex: -1,
      meituIndex: -1,
    };
  },
  computed: {
    miniWidth() {
      if (this.width > this.height) {
        return this.height;
      } else {
        return this.width;
      }
    },
  },
  mounted() {
    this.$emit("input", this.url);
  },
  methods: {
    handleChange() {
      //模拟数据
      if (this.type == "src") {
        this.url =
          "http://web.xuexiyuansu.com/images/miniprogramimages/teacher_1.png";
        this.$emit("input", this.url);
        return;
      }

      //真实选择
      const files = this.$refs.uploadInput.files;

      const file = files[0];
      const reader = new FileReader();
      const key = new Date().getTime() + "_" + Math.ceil(Math.random() * 99999);
      reader.readAsDataURL(file);
      reader.onload = () => {
        this.url = reader.result;
        this.$emit("input", this.url);
        // this.$nextTick(() => {
        //   this.uplaodAction(reader.result, file, key);
        // });
      };

      // this.$refs.uploadInput.value = [];
    },
    uplaodAction(res, file, key) {
      this.url =
        "http://web.xuexiyuansu.com/images/miniprogramimages/teacher_1.png";
      this.$emit("input", this.url);
      return;

      const xhr = new XMLHttpRequest();

      const url = this.action;
      xhr.open("POST", url, true);
      // xhr.setRequestHeader('Content-Type', 'multipart/form-data')

      let formData = new FormData();
      formData.append("file", file);

      xhr.send(formData);
      xhr.onreadystatechange = () => {
        console.log(xhr);
        if (xhr.readyState === 4) {
          let resData = JSON.parse(xhr.response);
          if (resData && resData.url) {
            this.$set(
              this.url,
              this.url.findIndex((item) => item.key === key),
              {
                ...this.url[this.url.findIndex((item) => item.key === key)],
                url: resData.url,
                percent: 100,
              }
            );
            setTimeout(() => {
              this.$set(
                this.url,
                this.url.findIndex((item) => item.key === key),
                {
                  ...this.url[this.url.findIndex((item) => item.key === key)],
                  status: "success",
                }
              );
              this.$emit("input", this.url);
            }, 200);
          } else {
            this.$set(
              this.url,
              this.url.findIndex((item) => item.key === key),
              {
                ...this.url[this.url.findIndex((item) => item.key === key)],
                status: "error",
              }
            );
            this.url.splice(
              this.url.findIndex((item) => item.key === key),
              1
            );
          }
        }
      };
      xhr.onprogress = (res) => {
        console.log("progress", res);
        if (res.total && res.loaded) {
          this.$set(
            this.url[this.url.findIndex((item) => item.key === key)],
            "percent",
            (res.loaded / res.total) * 100
          );
        }
      };
    },
    handleRemove(key) {
      this.url.splice(
        this.url.findIndex((item) => item.key === key),
        1
      );
    },
    handleEdit(key) {
      this.editIndex = this.url.findIndex((item) => item.key === key);

      this.$refs.uploadInput.click();
    },
    handleMeitu(key) {
      this.$emit(
        "on-meitu",
        this.url.findIndex((item) => item.key === key)
      );
    },
    handleAdd() {
      if (!this.disabled) {
        this.$refs.uploadInput.click();
      }
    },
    handlePreviewFile(key) {
      this.viewer && this.viewer.destroy();
      this.uploadId = "upload_" + new Date().getTime();

      console.log(this.viewer);
      this.$nextTick(() => {
        this.viewer = new Viewer(document.getElementById(this.uploadId));
        this.viewer.view(this.url.findIndex((item) => item.key === key));
      });
    },
  },
  watch: {
    url: {
      deep: true,
      handler(val) {
        // this.$emit('input', this.url)
      },
    },
  },
};
</script>

<style lang="scss">
.fm-uplaod-container {
  .is-disabled {
    position: relative;

    &::after {
      position: absolute;
      top: 0;
      bottom: 0;
      left: 0;
      right: 0;
      // background: rgba(0,0,0,.1);
      content: "";
      display: block;
      cursor: not-allowed;
    }
  }

  .upload-file {
    margin: 0 10px 10px 0;
    display: inline-flex;
    justify-content: center;
    align-items: center;
    // background: #fff;
    overflow: hidden;
    background-color: #fff;
    border: 1px solid #c0ccda;
    border-radius: 6px;
    box-sizing: border-box;
    position: relative;
    vertical-align: top;
    &:hover {
      .uplaod-action {
        display: flex;
      }
    }
    .uplaod-action {
      position: absolute;
      // top: 0;
      // height: 30px;
      bottom: 0;
      left: 0;
      right: 0;
      background: rgba(0, 0, 0, 0.6);
      display: none;
      justify-content: center;
      align-items: center;
      i {
        color: #fff;
        cursor: pointer;
        margin: 0 5px;
      }
    }
    &.is-success {
      .item-status {
        position: absolute;
        right: -15px;
        top: -6px;
        width: 40px;
        height: 24px;
        background: #13ce66;
        text-align: center;
        transform: rotate(45deg);
        box-shadow: 0 0 1pc 1px rgba(0, 0, 0, 0.2);
        & > i {
          font-size: 12px;
          margin-top: 11px;
          color: #fff;
          transform: rotate(-45deg);
        }
      }
    }
    &.uploading {
      &:before {
        display: block;
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.3);
      }
    }
    .upload-progress {
      position: absolute;
      .el-progress__text {
        color: #fff;
        font-size: 16px !important;
      }
    }
    img {
      max-width: 100%;
      max-height: 100%;
      vertical-align: middle;
    }
  }
  .el-upload--picture-card {
    position: relative;
    overflow: hidden;
    .el-icon-plus {
      position: absolute;
      top: 50%;
      left: 50%;
    }
  }
  .upload-input {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    display: block;
    opacity: 0;
    cursor: pointer;
  }

  .drag-img-list {
    display: inline;

    .ghost {
      position: relative;
      &::after {
        width: 100%;
        height: 100%;
        display: block;
        content: "";
        background: #fbfdff;
        position: absolute;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        border: 1px dashed #3bb3c2;
      }
    }

    & > div {
      cursor: move;
    }
  }
}

.viewer-container {
  z-index: 9999 !important;
}
</style>
